/**
 * Active Client JavaScript Module
 * Handles client selection, search/filter, and navigation to groups/settings
 */

(function() {
    'use strict';

    // ==================== STATE VARIABLES ====================
    let selectedClientId = null;
    let selectedFirstGroupId = null;
    let selectedRow = null;
    let currentFilter = 'all';

    // ==================== DOM ELEMENTS ====================
    const elements = {
        // Table
        tbody: document.getElementById('client-table-body'),
        
        // Action Buttons
        groupSettingBtn: document.getElementById('group-setting-btn'),
        idcardGroupBtn: document.getElementById('idcard-group-btn'),
        
        // Search & Filter
        searchInput: document.getElementById('search-input'),
        searchClear: document.getElementById('search-clear'),
        filterDropdown: document.getElementById('filter-dropdown'),
        dropdownToggle: document.getElementById('dropdown-toggle'),
        dropdownOptions: document.getElementById('dropdown-options'),
        selectedText: document.getElementById('selected-text'),
        
        // Empty State
        emptyState: document.getElementById('empty-state')
    };

    // ==================== ROW SELECTION ====================
    function selectRow(row) {
        if (!row || row.classList.contains('no-data-row')) return;
        
        // Remove previous selection
        document.querySelectorAll('#client-table-body tr.selected').forEach(r => {
            r.classList.remove('selected');
        });
        
        // Select new row
        row.classList.add('selected');
        selectedClientId = row.dataset.clientId;
        selectedFirstGroupId = row.dataset.firstGroupId || null;
        selectedRow = row;
        
        // Enable buttons
        updateActionButtons();
    }

    function clearSelection() {
        document.querySelectorAll('#client-table-body tr.selected').forEach(r => {
            r.classList.remove('selected');
        });
        selectedClientId = null;
        selectedFirstGroupId = null;
        selectedRow = null;
        updateActionButtons();
    }

    function updateActionButtons() {
        const hasSelection = selectedClientId !== null;
        if (elements.groupSettingBtn) elements.groupSettingBtn.disabled = !hasSelection;
        if (elements.idcardGroupBtn) elements.idcardGroupBtn.disabled = !hasSelection;
    }

    // ==================== SEARCH & FILTER ====================
    function performSearch() {
        const searchTerm = elements.searchInput?.value.toLowerCase().trim() || '';
        const rows = document.querySelectorAll('#client-table-body tr:not(.no-data-row)');
        let visibleCount = 0;
        
        // Column index mapping
        const filterColumnMap = {
            'all': null,
            'name': 0,
            'email': 1,
            'phone': 2
        };
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let match = false;
            
            if (currentFilter === 'all' || !searchTerm) {
                // Search all columns
                const text = row.textContent.toLowerCase();
                match = searchTerm === '' || text.includes(searchTerm);
            } else {
                // Search specific column
                const columnIndex = filterColumnMap[currentFilter];
                if (columnIndex !== null && cells[columnIndex]) {
                    const cellText = cells[columnIndex].textContent.toLowerCase();
                    match = cellText.includes(searchTerm);
                }
            }
            
            row.style.display = match ? '' : 'none';
            if (match) visibleCount++;
        });
        
        // Update search clear button visibility
        if (elements.searchClear) {
            elements.searchClear.style.display = searchTerm ? 'flex' : 'none';
        }
        
        // Update empty state
        updateEmptyState(visibleCount === 0 && searchTerm !== '');
        
        // Update pagination info
        updateRowCount(visibleCount);
    }

    function updateEmptyState(showEmpty = false) {
        if (elements.emptyState) {
            elements.emptyState.style.display = showEmpty ? 'flex' : 'none';
        }
    }

    function updateRowCount(count) {
        const rowCountEl = document.getElementById('row-count');
        if (rowCountEl) {
            const total = document.querySelectorAll('#client-table-body tr:not(.no-data-row)').length;
            rowCountEl.textContent = `Showing ${count} of ${total}`;
        }
    }

    // ==================== FILTER DROPDOWN ====================
    function setupFilterDropdown() {
        if (!elements.dropdownToggle || !elements.dropdownOptions) return;
        
        elements.dropdownToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            elements.filterDropdown.classList.toggle('open');
        });
        
        elements.dropdownOptions.querySelectorAll('.dropdown-option').forEach(option => {
            option.addEventListener('click', function() {
                // Update selected state
                elements.dropdownOptions.querySelectorAll('.dropdown-option').forEach(o => {
                    o.classList.remove('selected');
                });
                this.classList.add('selected');
                
                // Update display text
                elements.selectedText.textContent = this.textContent;
                currentFilter = this.dataset.value;
                
                // Update placeholder
                if (elements.searchInput) {
                    const filterText = this.dataset.value === 'all' ? 'All' : this.textContent;
                    elements.searchInput.placeholder = `Search ${filterText}...`;
                }
                
                // Close dropdown
                elements.filterDropdown.classList.remove('open');
                
                // Re-run search with new filter
                performSearch();
            });
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function() {
            elements.filterDropdown?.classList.remove('open');
        });
    }

    // ==================== URL HIGHLIGHT ====================
    function highlightFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const highlightId = urlParams.get('highlight');
        
        if (highlightId) {
            const targetRow = document.querySelector(`tr[data-client-id="${highlightId}"]`);
            
            if (targetRow) {
                selectRow(targetRow);
                
                setTimeout(() => {
                    targetRow.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'center' 
                    });
                }, 100);
                
                // Add highlight animation
                targetRow.classList.add('highlight');
                
                setTimeout(() => {
                    targetRow.classList.remove('highlight');
                    const newUrl = new URL(window.location);
                    newUrl.searchParams.delete('highlight');
                    window.history.replaceState({}, '', newUrl);
                }, 2000);
            }
        }
    }

    // ==================== EVENT LISTENERS ====================
    function setupEventListeners() {
        // Table row selection
        if (elements.tbody) {
            // Row click handler
            elements.tbody.addEventListener('click', function(e) {
                const row = e.target.closest('tr');
                if (row && !row.classList.contains('no-data-row')) {
                    selectRow(row);
                }
            });
            
            // Double-click to go to ID Card Groups
            elements.tbody.addEventListener('dblclick', function(e) {
                const row = e.target.closest('tr');
                if (row && row.dataset.clientId) {
                    window.location.href = `/panel/client/${row.dataset.clientId}/groups/`;
                }
            });
        }
        
        // Group Setting button
        if (elements.groupSettingBtn) {
            elements.groupSettingBtn.addEventListener('click', function() {
                if (selectedClientId) {
                    window.location.href = `/panel/client/${selectedClientId}/settings/`;
                }
            });
        }
        
        // ID Card Group button
        if (elements.idcardGroupBtn) {
            elements.idcardGroupBtn.addEventListener('click', function() {
                if (selectedClientId) {
                    window.location.href = `/panel/client/${selectedClientId}/groups/`;
                }
            });
        }
        
        // Search input
        if (elements.searchInput) {
            elements.searchInput.addEventListener('input', performSearch);
        }
        
        // Search clear button
        if (elements.searchClear) {
            elements.searchClear.addEventListener('click', function() {
                elements.searchInput.value = '';
                performSearch();
                elements.searchInput.focus();
            });
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl+F to focus search
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                elements.searchInput?.focus();
            }
            
            // Escape to clear search
            if (e.key === 'Escape') {
                if (elements.searchInput && elements.searchInput === document.activeElement) {
                    elements.searchInput.value = '';
                    performSearch();
                    elements.searchInput.blur();
                }
            }
            
            // Enter to go to groups when row is selected
            if (e.key === 'Enter' && selectedClientId) {
                // Don't navigate if user is typing in an input or the search overlay is open
                const active = document.activeElement;
                if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)) return;
                const searchOverlay = document.getElementById('globalSearchOverlay');
                if (searchOverlay && searchOverlay.classList.contains('active')) return;
                window.location.href = `/panel/client/${selectedClientId}/groups/`;
            }
        });
    }

    // ==================== INITIALIZATION ====================
    function init() {
        setupEventListeners();
        setupFilterDropdown();
        highlightFromUrl();
        
        // Initialize row count
        const totalRows = document.querySelectorAll('#client-table-body tr:not(.no-data-row)').length;
        updateRowCount(totalRows);
        
        // Hide search clear initially
        if (elements.searchClear) {
            elements.searchClear.style.display = 'none';
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
